

#include <stdint.h>
#include "tm4c123gh6pm.h"


void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode

volatile uint32_t EdgeInterruptFlag;
uint32_t player1button;
uint32_t player2button;
uint32_t level1button;
uint32_t level2button;
uint32_t level3button;
// global variable visible in Watch window of debugger
// increments at least once per button press
void buttons_Init(void){  
  player1button = 0;
  player2button = 0;	
	level1button = 0;
	level2button= 0;
	level3button = 0;
	EdgeInterruptFlag = 0;
	//// Player buttons 
  SYSCTL_RCGCGPIO_R |= 0x00000002; // (a) activate clock for port B
	int wait = 4;
	while (wait >0){ wait--;}
  //FallingEdges = 0;             // (b) initialize counter
  GPIO_PORTB_DIR_R &= ~0x30;    // (c) make PB4 PB5 in (built-in button)
  GPIO_PORTB_AFSEL_R &= ~0x30;  //     disable alt funct on PB4 PB5
  GPIO_PORTB_DEN_R |= 0x30;     //     enable digital I/O on PB4 PB5 
  //GPIO_PORTF_PCTL_R &= ~0x000F0000; // configure PB4 PB5 as GPIO
  GPIO_PORTB_AMSEL_R = 0;       //     disable analog functionality on Pb
  GPIO_PORTB_PDR_R |= 0x30;     //     enable weak pull-up on PB4 PB5
  GPIO_PORTB_IS_R &= ~0x30;     // (d) PB4 PB5 is edge-sensitive
  GPIO_PORTB_IBE_R &= ~0x30;    //     PB4 PB5 is not both edges
  GPIO_PORTB_IEV_R |= 0x30;    //     PB4 PB5 rising edge event
  GPIO_PORTB_ICR_R = 0x30;      // (e) clear flag4
  GPIO_PORTB_IM_R |= 0x30;      // (f) arm interrupt on PB4 PB5 *** No IME bit as mentioned in Book ***
  NVIC_PRI0_R = (NVIC_PRI0_R&0xFFFF00FF)|0x0000A000; // (g) priority 5
  NVIC_EN0_R = 0x02;      // (h) enable interrupt 30 in NVIC
	
	////////////// Level select buttons
	SYSCTL_RCGCGPIO_R |= 0x00000010; // (a) activate clock for port E
		wait = 4;
	while (wait >0){ wait--;}
  //FallingEdges = 0;             // (b) initialize counter
  GPIO_PORTE_DIR_R &= ~0x0E;    // (c) make PE1-PE3 in
  GPIO_PORTE_AFSEL_R &= ~0x0E;  //     disable alt funct on PE1-PE3
  GPIO_PORTE_DEN_R |= 0x0E;     //     enable digital I/O on PPE1-PE3
  //GPIO_PORTF_PCTL_R &= ~0x000F0000; // configure PB4 PB5 as GPIO
  GPIO_PORTE_AMSEL_R = 0;       //     disable analog functionality on PE
  GPIO_PORTE_PDR_R |= 0x0E;     //     enable weak pull-up on PE1-PE3
  GPIO_PORTE_IS_R &= ~0x0E;     // (d) PE1-PE3 is edge-sensitive
  GPIO_PORTE_IBE_R &= ~0x0E;    //    PE1-PE3 is not both edges
  GPIO_PORTE_IEV_R |= 0x0E;    //     PE1-PE3 rising edge event
  GPIO_PORTE_ICR_R = 0x0E;      // (e) clear flag4
  GPIO_PORTE_IM_R |= 0x0E;      // (f) arm interrupt on PE1-PE3 *** No IME bit as mentioned in Book ***
    NVIC_PRI1_R = (NVIC_PRI1_R&0xFFFFFF0F)|0x000000A0; // (g) priority 5
  NVIC_EN0_R = 0x10;      // (h) enable interrupt 30 in NVIC
  EnableInterrupts();           // (i) Clears the I bit
}

void GPIOPortB_Handler(void){
	if((GPIO_PORTB_RIS_R & 0x10) == 0x10){	//checks if player1 button pressed
		player1button = 0x01;
		GPIO_PORTB_ICR_R = 0x10;      // acknowledge flag4
	}
	if((GPIO_PORTB_RIS_R & 0x20) == 0x20){	//checks if player2 button pressed
		player2button = 0x01;
		GPIO_PORTB_ICR_R = 0x20;      // acknowledge flag4
	}
}
	////// level select
	
	void GPIOPortE_Handler(void){
		if((GPIO_PORTE_RIS_R & 0x02) == 0x02){	//checks if player2 button pressed
		 level1button = 0x01;
		GPIO_PORTE_ICR_R = 0x02;      // acknowledge flag4
	}
			if((GPIO_PORTE_RIS_R & 0x04) == 0x04){	//checks if player2 button pressed
		level2button = 0x01;
		GPIO_PORTE_ICR_R = 0x04;      // acknowledge flag4
	}
				if((GPIO_PORTE_RIS_R & 0x08) == 0x08){	//checks if player2 button pressed
		level3button = 0x01;
		GPIO_PORTE_ICR_R = 0x08;      // acknowledge flag4
}
 
  
}
