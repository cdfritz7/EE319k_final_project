# Lab-10-C-SpaceInvader
Game design (Space Invader) competition, written in C (simulated and board, groups of two)
