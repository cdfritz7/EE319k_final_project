#include <stdint.h>
#include "tm4c123gh6pm.h"

extern uint32_t player1button;
extern uint32_t player2button;
extern uint32_t level1button;
extern uint32_t level2button;
extern uint32_t level3button;

void buttons_Init(void);

void GPIOPortB_Handler(void);

